package com.cyberlab.toolkit.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.cyberlab.toolkit.ui.theme.AccentAmber

/**
 * Displayed before any scan is started. Requires explicit acknowledgement
 * that the user owns or has permission to test the target.
 */
@Composable
fun AuthorizationNotice(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(AccentAmber.copy(alpha = 0.12f))
            .padding(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(Icons.Filled.Warning, contentDescription = null, tint = AccentAmber)
        Spacer(Modifier.width(10.dp))
        Text(
            "Only scan devices, networks, and domains you own or have explicit " +
                "written authorization to test. Unauthorized scanning may be illegal " +
                "in your jurisdiction.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

/**
 * Blocking confirmation dialog shown the first time a scan-capable screen
 * is opened in a session, or whenever explicit re-confirmation is desired.
 */
@Composable
fun AuthorizationConfirmDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Authorization required") },
        text = {
            Text(
                "This tool will actively probe the target you specify. Only proceed " +
                    "if you own the target or have explicit permission to test it. " +
                    "Scanning systems without authorization may violate the law."
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text("I confirm I'm authorized") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
