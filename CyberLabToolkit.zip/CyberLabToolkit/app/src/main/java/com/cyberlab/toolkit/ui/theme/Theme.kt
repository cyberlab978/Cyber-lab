package com.cyberlab.toolkit.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Cybersecurity-themed dark palette
val BackgroundDark = Color(0xFF0A0E14)
val SurfaceDark = Color(0xFF121820)
val SurfaceVariantDark = Color(0xFF1A2230)
val AccentGreen = Color(0xFF00E676)      // terminal green - success / open
val AccentAmber = Color(0xFFFFC107)      // warning / filtered
val AccentRed = Color(0xFFFF5252)        // danger / closed / vulnerable
val AccentCyan = Color(0xFF18FFFF)       // primary accent
val TextPrimary = Color(0xFFE0F2F1)
val TextSecondary = Color(0xFF8FA3AD)

private val CyberLabColorScheme = darkColorScheme(
    primary = AccentCyan,
    secondary = AccentGreen,
    tertiary = AccentAmber,
    background = BackgroundDark,
    surface = SurfaceDark,
    surfaceVariant = SurfaceVariantDark,
    error = AccentRed,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onError = Color.Black
)

@Composable
fun CyberLabToolkitTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CyberLabColorScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
