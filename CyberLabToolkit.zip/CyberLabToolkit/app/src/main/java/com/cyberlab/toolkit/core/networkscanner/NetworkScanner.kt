package com.cyberlab.toolkit.core.networkscanner

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.FileReader
import java.net.InetAddress
import java.net.NetworkInterface

data class DiscoveredDevice(
    val ipAddress: String,
    val hostname: String?,
    val macAddress: String?,
    val isReachable: Boolean
)

/**
 * Scans the local /24 subnet the device is currently connected to.
 * Uses ICMP-style reachability checks (InetAddress.isReachable) which is
 * safe, non-intrusive, and does not attempt to exploit discovered hosts.
 */
class NetworkScanner {

    /** Returns this device's local IPv4 address, or null if unavailable. */
    fun getLocalIpAddress(): String? {
        val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
        for (intf in interfaces) {
            if (!intf.isUp || intf.isLoopback) continue
            for (addr in intf.inetAddresses) {
                if (!addr.isLoopbackAddress && addr.hostAddress?.contains(":") == false) {
                    return addr.hostAddress
                }
            }
        }
        return null
    }

    /** Derives the /24 subnet prefix, e.g. "192.168.1" from "192.168.1.42". */
    fun getSubnetPrefix(localIp: String): String {
        val parts = localIp.split(".")
        return if (parts.size == 4) "${parts[0]}.${parts[1]}.${parts[2]}" else localIp
    }

    /**
     * Sweeps addresses 1-254 in the given /24 subnet concurrently.
     * timeoutMs controls per-host reachability timeout.
     * onProgress reports (checked, total) as the scan proceeds.
     */
    suspend fun scanSubnet(
        subnetPrefix: String,
        timeoutMs: Int = 300,
        onProgress: (checked: Int, total: Int) -> Unit = { _, _ -> }
    ): List<DiscoveredDevice> = withContext(Dispatchers.IO) {
        val total = 254
        var checked = 0
        val arpTable = readArpTable()

        val deferred = (1..254).map { host ->
            async {
                val ip = "$subnetPrefix.$host"
                val result = try {
                    val addr = InetAddress.getByName(ip)
                    val reachable = addr.isReachable(timeoutMs)
                    if (reachable) {
                        DiscoveredDevice(
                            ipAddress = ip,
                            hostname = addr.canonicalHostName.takeIf { it != ip },
                            macAddress = arpTable[ip],
                            isReachable = true
                        )
                    } else null
                } catch (e: Exception) {
                    null
                }
                synchronized(this) {
                    checked++
                    onProgress(checked, total)
                }
                result
            }
        }
        deferred.awaitAll().filterNotNull()
    }

    /**
     * Best-effort read of /proc/net/arp for MAC addresses of recently-seen
     * hosts. Newer Android versions restrict this file, so it may return
     * an empty map; that's expected and handled gracefully.
     */
    private fun readArpTable(): Map<String, String> {
        val map = mutableMapOf<String, String>()
        try {
            BufferedReader(FileReader("/proc/net/arp")).use { reader ->
                reader.readLine() // header
                reader.forEachLine { line ->
                    val cols = line.trim().split(Regex("\\s+"))
                    if (cols.size >= 4) {
                        val ip = cols[0]
                        val mac = cols[3]
                        if (mac != "00:00:00:00:00:00") map[ip] = mac
                    }
                }
            }
        } catch (e: Exception) {
            // Not accessible on this device/OS version - MAC addresses will
            // simply show as unavailable. This is expected behavior.
        }
        return map
    }
}
