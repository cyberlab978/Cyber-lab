package com.cyberlab.toolkit.ui.networkscanner

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cyberlab.toolkit.core.networkscanner.DiscoveredDevice
import com.cyberlab.toolkit.core.networkscanner.NetworkScanner
import com.cyberlab.toolkit.ui.components.AuthorizationNotice
import com.cyberlab.toolkit.ui.components.TerminalLine
import com.cyberlab.toolkit.ui.components.TerminalPanel
import com.cyberlab.toolkit.ui.theme.AccentGreen
import kotlinx.coroutines.launch

@Composable
fun NetworkScannerScreen() {
    val scanner = remember { NetworkScanner() }
    val scope = rememberCoroutineScope()

    var isScanning by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var devices by remember { mutableStateOf<List<DiscoveredDevice>>(emptyList()) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Local Network Scanner", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        AuthorizationNotice()
        Spacer(Modifier.height(14.dp))

        Button(
            onClick = {
                scope.launch {
                    isScanning = true
                    progress = 0f
                    devices = emptyList()
                    val localIp = scanner.getLocalIpAddress()
                    if (localIp != null) {
                        val subnet = scanner.getSubnetPrefix(localIp)
                        devices = scanner.scanSubnet(subnet) { checked, total ->
                            progress = checked / total.toFloat()
                        }
                    }
                    isScanning = false
                }
            },
            enabled = !isScanning,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isScanning) "Scanning..." else "Start Scan")
        }

        if (isScanning) {
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
        }

        Spacer(Modifier.height(16.dp))

        if (devices.isNotEmpty()) {
            Text("${devices.size} device(s) found", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            TerminalPanel(modifier = Modifier.weight(1f)) {
                LazyColumn {
                    items(devices) { device ->
                        TerminalLine(
                            "${device.ipAddress}  ${device.hostname ?: "-"}  ${device.macAddress ?: "MAC n/a"}",
                            color = AccentGreen
                        )
                    }
                }
            }
        } else if (!isScanning) {
            Text(
                "No devices scanned yet. Start a scan to discover devices on your current network.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
