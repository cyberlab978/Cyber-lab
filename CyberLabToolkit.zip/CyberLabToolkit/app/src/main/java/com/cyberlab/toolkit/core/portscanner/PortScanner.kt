package com.cyberlab.toolkit.core.portscanner

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.time.Instant

enum class PortStatus { OPEN, CLOSED, FILTERED }

data class PortResult(
    val port: Int,
    val status: PortStatus,
    val serviceName: String?,
    val timestamp: Instant
)

val COMMON_PORTS = listOf(
    21 to "FTP", 22 to "SSH", 23 to "Telnet", 25 to "SMTP", 53 to "DNS",
    80 to "HTTP", 110 to "POP3", 143 to "IMAP", 443 to "HTTPS", 445 to "SMB",
    3306 to "MySQL", 3389 to "RDP", 5432 to "PostgreSQL", 8080 to "HTTP-Alt",
    8443 to "HTTPS-Alt"
)

/**
 * Performs simple TCP connect() checks against a target the user has
 * explicitly entered and confirmed authorization for. This is a passive
 * connectivity check only - it never attempts banner-grabbing exploits,
 * brute force, or protocol-level attacks.
 */
class PortScanner {

    suspend fun scanPorts(
        host: String,
        ports: List<Int>,
        timeoutMs: Int = 500,
        onProgress: (checked: Int, total: Int) -> Unit = { _, _ -> }
    ): List<PortResult> = withContext(Dispatchers.IO) {
        var checked = 0
        val total = ports.size
        val serviceMap = COMMON_PORTS.toMap()

        val deferred = ports.map { port ->
            async {
                val status = try {
                    Socket().use { socket ->
                        socket.connect(InetSocketAddress(host, port), timeoutMs)
                        PortStatus.OPEN
                    }
                } catch (e: java.net.SocketTimeoutException) {
                    PortStatus.FILTERED
                } catch (e: Exception) {
                    PortStatus.CLOSED
                }
                val result = PortResult(
                    port = port,
                    status = status,
                    serviceName = serviceMap[port],
                    timestamp = Instant.now()
                )
                synchronized(this) {
                    checked++
                    onProgress(checked, total)
                }
                result
            }
        }
        deferred.awaitAll().sortedBy { it.port }
    }

    fun parsePortRange(input: String): List<Int> {
        // Accepts "1-1024", "80,443,8080", or a mix "22,80-90,443"
        val ports = mutableSetOf<Int>()
        input.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { token ->
            if (token.contains("-")) {
                val (startStr, endStr) = token.split("-").map { it.trim() }
                val start = startStr.toIntOrNull()
                val end = endStr.toIntOrNull()
                if (start != null && end != null && start in 1..65535 && end in start..65535) {
                    ports.addAll(start..end)
                }
            } else {
                token.toIntOrNull()?.let { if (it in 1..65535) ports.add(it) }
            }
        }
        return ports.sorted()
    }
}
