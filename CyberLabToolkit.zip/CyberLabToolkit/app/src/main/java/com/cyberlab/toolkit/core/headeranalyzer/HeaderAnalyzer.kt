package com.cyberlab.toolkit.core.headeranalyzer

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class SecurityHeaderCheck(
    val headerName: String,
    val present: Boolean,
    val value: String?,
    val explanation: String
)

data class HeaderScanResult(
    val url: String,
    val statusCode: Int?,
    val checks: List<SecurityHeaderCheck>,
    val score: Int, // 0-100
    val error: String? = null
)

/**
 * Fetches response headers from a URL the user has entered and confirmed
 * they're authorized to test, then reports which common security headers
 * are present or missing with plain-English explanations. Purely
 * observational - issues one GET request and reads headers, no
 * exploitation attempts of any kind.
 */
class HeaderAnalyzer {

    private val headerDefinitions = listOf(
        Triple(
            "Strict-Transport-Security", 20,
            "Tells browsers to only connect over HTTPS, preventing downgrade/SSL-stripping attacks."
        ),
        Triple(
            "Content-Security-Policy", 20,
            "Restricts which sources scripts, styles, and other resources can load from, mitigating XSS."
        ),
        Triple(
            "X-Content-Type-Options", 15,
            "Set to 'nosniff' to stop browsers from MIME-sniffing away from the declared content type."
        ),
        Triple(
            "X-Frame-Options", 15,
            "Prevents the page from being embedded in a frame/iframe, mitigating clickjacking."
        ),
        Triple(
            "Referrer-Policy", 15,
            "Controls how much referrer information is sent with outgoing requests."
        ),
        Triple(
            "Permissions-Policy", 15,
            "Restricts which browser features (camera, mic, geolocation, etc.) the page can use."
        )
    )

    suspend fun analyze(targetUrl: String): HeaderScanResult = withContext(Dispatchers.IO) {
        val normalizedUrl = if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
            "https://$targetUrl"
        } else targetUrl

        var connection: HttpURLConnection? = null
        try {
            val url = URL(normalizedUrl)
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                instanceFollowRedirects = true
            }
            val status = connection.responseCode
            val headerFields = connection.headerFields

            var score = 0
            val checks = headerDefinitions.map { (name, weight, explanation) ->
                val matchKey = headerFields.keys.firstOrNull { it != null && it.equals(name, ignoreCase = true) }
                val value = matchKey?.let { headerFields[it]?.joinToString("; ") }
                val present = value != null
                if (present) score += weight
                SecurityHeaderCheck(name, present, value, explanation)
            }

            HeaderScanResult(normalizedUrl, status, checks, score.coerceIn(0, 100))
        } catch (e: Exception) {
            HeaderScanResult(normalizedUrl, null, emptyList(), 0, e.message ?: "Request failed")
        } finally {
            connection?.disconnect()
        }
    }
}
