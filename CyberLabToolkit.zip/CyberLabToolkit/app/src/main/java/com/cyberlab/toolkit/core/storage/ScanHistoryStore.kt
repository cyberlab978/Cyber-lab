package com.cyberlab.toolkit.core.storage

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant

enum class ScanType { NETWORK, PORT, HEADER, DNS }

data class ScanHistoryEntry(
    val id: String,
    val type: ScanType,
    val target: String,
    val summary: String,
    val timestamp: Instant
)

/**
 * Stores only non-sensitive scan metadata (target, type, short summary,
 * timestamp) as local JSON on device storage. Never stores raw password
 * text, full response bodies, or anything else sensitive - only enough
 * to let the user recall and re-export what they scanned.
 */
class ScanHistoryStore(private val context: Context) {

    private val file: File
        get() = File(context.filesDir, "scan_history.json")

    fun add(entry: ScanHistoryEntry) {
        val all = getAll().toMutableList()
        all.add(0, entry)
        save(all)
    }

    fun getAll(): List<ScanHistoryEntry> {
        if (!file.exists()) return emptyList()
        return try {
            val text = file.readText()
            val arr = JSONArray(text)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ScanHistoryEntry(
                    id = o.getString("id"),
                    type = ScanType.valueOf(o.getString("type")),
                    target = o.getString("target"),
                    summary = o.getString("summary"),
                    timestamp = Instant.parse(o.getString("timestamp"))
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun delete(id: String) {
        save(getAll().filterNot { it.id == id })
    }

    fun clear() {
        save(emptyList())
    }

    fun search(query: String): List<ScanHistoryEntry> =
        getAll().filter {
            it.target.contains(query, ignoreCase = true) ||
                it.summary.contains(query, ignoreCase = true)
        }

    fun exportAsCsv(): String {
        val header = "id,type,target,summary,timestamp"
        val rows = getAll().joinToString("\n") { e ->
            "${e.id},${e.type},${e.target.replace(",", " ")},${e.summary.replace(",", " ")},${e.timestamp}"
        }
        return "$header\n$rows"
    }

    fun exportAsTxt(): String =
        getAll().joinToString("\n\n") { e ->
            "[${e.timestamp}] ${e.type} - ${e.target}\n${e.summary}"
        }

    private fun save(entries: List<ScanHistoryEntry>) {
        val arr = JSONArray()
        entries.forEach { e ->
            val o = JSONObject()
            o.put("id", e.id)
            o.put("type", e.type.name)
            o.put("target", e.target)
            o.put("summary", e.summary)
            o.put("timestamp", e.timestamp.toString())
            arr.put(o)
        }
        file.writeText(arr.toString())
    }
}
