package com.cyberlab.toolkit.ui.portscanner

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cyberlab.toolkit.core.portscanner.PortResult
import com.cyberlab.toolkit.core.portscanner.PortScanner
import com.cyberlab.toolkit.core.portscanner.PortStatus
import com.cyberlab.toolkit.ui.components.AuthorizationConfirmDialog
import com.cyberlab.toolkit.ui.components.AuthorizationNotice
import com.cyberlab.toolkit.ui.components.StatusPill
import com.cyberlab.toolkit.ui.components.TerminalPanel
import com.cyberlab.toolkit.ui.theme.AccentAmber
import com.cyberlab.toolkit.ui.theme.AccentGreen
import com.cyberlab.toolkit.ui.theme.AccentRed
import kotlinx.coroutines.launch

@Composable
fun PortScannerScreen() {
    val scanner = remember { PortScanner() }
    val scope = rememberCoroutineScope()

    var host by remember { mutableStateOf("") }
    var portInput by remember { mutableStateOf("1-1024") }
    var showAuthDialog by remember { mutableStateOf(false) }
    var isScanning by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var results by remember { mutableStateOf<List<PortResult>>(emptyList()) }

    fun runScan() {
        val ports = scanner.parsePortRange(portInput)
        if (host.isBlank() || ports.isEmpty()) return
        scope.launch {
            isScanning = true
            progress = 0f
            results = emptyList()
            results = scanner.scanPorts(host.trim(), ports) { checked, total ->
                progress = checked / total.toFloat()
            }
            isScanning = false
        }
    }

    if (showAuthDialog) {
        AuthorizationConfirmDialog(
            onConfirm = { showAuthDialog = false; runScan() },
            onDismiss = { showAuthDialog = false }
        )
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Authorized Port Scanner", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        AuthorizationNotice()
        Spacer(Modifier.height(14.dp))

        OutlinedTextField(
            value = host,
            onValueChange = { host = it },
            label = { Text("Target IP or domain you're authorized to test") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = portInput,
            onValueChange = { portInput = it },
            label = { Text("Ports (e.g. 1-1024 or 22,80,443)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(6.dp))
        Row {
            AssistChip(onClick = { portInput = "21,22,23,25,53,80,110,143,443,445,3306,3389,8080" }, label = { Text("Common ports") })
            Spacer(Modifier.width(8.dp))
            AssistChip(onClick = { portInput = "1-65535" }, label = { Text("All ports") })
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { showAuthDialog = true },
            enabled = !isScanning && host.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isScanning) "Scanning..." else "Start Port Scan")
        }

        if (isScanning) {
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        }

        Spacer(Modifier.height(16.dp))
        if (results.isNotEmpty()) {
            TerminalPanel(modifier = Modifier.weight(1f)) {
                LazyColumn {
                    items(results) { r ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${r.port}  ${r.serviceName ?: ""}")
                            StatusPill(
                                r.status.name,
                                when (r.status) {
                                    PortStatus.OPEN -> AccentGreen
                                    PortStatus.CLOSED -> AccentRed
                                    PortStatus.FILTERED -> AccentAmber
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
