package com.cyberlab.toolkit.ui.history

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cyberlab.toolkit.core.storage.ScanHistoryEntry
import com.cyberlab.toolkit.core.storage.ScanHistoryStore

@Composable
fun HistoryScreen() {
    val context = LocalContext.current
    val store = remember { ScanHistoryStore(context) }
    var query by remember { mutableStateOf("") }
    var entries by remember { mutableStateOf(store.getAll()) }

    val visible = if (query.isBlank()) entries else store.search(query)

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Scan History", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search history") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(10.dp))

        if (visible.isEmpty()) {
            Text("No scan history yet.", style = MaterialTheme.typography.bodySmall)
        } else {
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(visible, key = { it.id }) { entry: ScanHistoryEntry ->
                    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Row(
                            Modifier.fillMaxWidth().padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("${entry.type} - ${entry.target}", style = MaterialTheme.typography.bodyMedium)
                                Text(entry.summary, style = MaterialTheme.typography.bodySmall)
                                Text(entry.timestamp.toString(), style = MaterialTheme.typography.labelSmall)
                            }
                            IconButton(onClick = {
                                store.delete(entry.id)
                                entries = store.getAll()
                            }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row {
                OutlinedButton(onClick = {
                    store.clear()
                    entries = store.getAll()
                }) { Text("Clear All") }
            }
        }
    }
}
