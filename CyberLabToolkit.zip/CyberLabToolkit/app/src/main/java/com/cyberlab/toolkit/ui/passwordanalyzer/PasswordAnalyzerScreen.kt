package com.cyberlab.toolkit.ui.passwordanalyzer

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.cyberlab.toolkit.core.passwordanalyzer.PasswordAnalyzer
import com.cyberlab.toolkit.core.passwordanalyzer.StrengthLevel
import com.cyberlab.toolkit.ui.theme.AccentAmber
import com.cyberlab.toolkit.ui.theme.AccentGreen
import com.cyberlab.toolkit.ui.theme.AccentRed

@Composable
fun PasswordAnalyzerScreen() {
    val analyzer = remember { PasswordAnalyzer() }
    var password by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    val analysis = remember(password) { analyzer.analyze(password) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Password Strength Analyzer", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Analyzed entirely on-device. Never uploaded, logged, or saved.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Enter a password to test") },
            singleLine = true,
            visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            trailingIcon = {
                IconButton(onClick = { visible = !visible }) {
                    Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = null)
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        if (password.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            val (label, color) = when (analysis.strength) {
                StrengthLevel.VERY_WEAK -> "Very Weak" to AccentRed
                StrengthLevel.WEAK -> "Weak" to AccentRed
                StrengthLevel.FAIR -> "Fair" to AccentAmber
                StrengthLevel.STRONG -> "Strong" to AccentGreen
                StrengthLevel.VERY_STRONG -> "Very Strong" to AccentGreen
            }
            Text(label, style = MaterialTheme.typography.titleLarge, color = color)
            LinearProgressIndicator(
                progress = { (analysis.entropyBits / 80.0).coerceIn(0.0, 1.0).toFloat() },
                modifier = Modifier.fillMaxWidth(),
                color = color
            )
            Text("Estimated entropy: ${analysis.entropyBits.toInt()} bits", style = MaterialTheme.typography.bodySmall)

            if (analysis.issues.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text("Issues", style = MaterialTheme.typography.titleSmall)
                analysis.issues.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            }
            if (analysis.suggestions.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text("Suggestions", style = MaterialTheme.typography.titleSmall)
                analysis.suggestions.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}
