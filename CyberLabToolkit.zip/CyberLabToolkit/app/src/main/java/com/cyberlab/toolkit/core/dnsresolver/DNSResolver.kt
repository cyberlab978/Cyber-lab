package com.cyberlab.toolkit.core.dnsresolver

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.UnknownHostException

data class DNSResult(
    val query: String,
    val aRecords: List<String>,
    val aaaaRecords: List<String>,
    val reverseDns: String?,
    val error: String? = null
)

/**
 * DNS lookups using the platform resolver (java.net.InetAddress), which
 * covers A/AAAA records and reverse DNS without any extra permissions.
 *
 * NOTE: Android's built-in APIs do not expose raw MX / NS / TXT records.
 * To support those, add a pure-Kotlin/Java DNS library such as `dnsjava`
 * (org.xbill:dnsjava) as a Gradle dependency and query record types
 * directly against a resolver, e.g.:
 *   val records = Lookup(domain, Type.MX).run()
 * This is called out here rather than bundled, since dnsjava issues raw
 * UDP/TCP DNS queries and pulling it in should be a deliberate choice by
 * whoever maintains the project, not a silent addition.
 */
class DNSResolver {

    suspend fun lookup(domain: String): DNSResult = withContext(Dispatchers.IO) {
        try {
            val addresses = InetAddress.getAllByName(domain)
            val a = addresses.filter { it.address.size == 4 }.map { it.hostAddress ?: "" }
            val aaaa = addresses.filter { it.address.size == 16 }.map { it.hostAddress ?: "" }
            val reverse = addresses.firstOrNull()?.let { addr ->
                val canonical = addr.canonicalHostName
                if (canonical != addr.hostAddress) canonical else null
            }
            DNSResult(domain, a, aaaa, reverse)
        } catch (e: UnknownHostException) {
            DNSResult(domain, emptyList(), emptyList(), null, "Host not found")
        } catch (e: Exception) {
            DNSResult(domain, emptyList(), emptyList(), null, e.message ?: "Lookup failed")
        }
    }

    suspend fun reverseLookup(ipAddress: String): String? = withContext(Dispatchers.IO) {
        try {
            val addr = InetAddress.getByName(ipAddress)
            val canonical = addr.canonicalHostName
            if (canonical != ipAddress) canonical else null
        } catch (e: Exception) {
            null
        }
    }
}
