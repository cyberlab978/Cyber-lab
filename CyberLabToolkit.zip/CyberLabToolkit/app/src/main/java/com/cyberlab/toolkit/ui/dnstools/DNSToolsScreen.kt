package com.cyberlab.toolkit.ui.dnstools

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cyberlab.toolkit.core.dnsresolver.DNSResolver
import com.cyberlab.toolkit.core.dnsresolver.DNSResult
import com.cyberlab.toolkit.ui.components.TerminalLine
import com.cyberlab.toolkit.ui.components.TerminalPanel
import com.cyberlab.toolkit.ui.theme.AccentCyan
import kotlinx.coroutines.launch

@Composable
fun DNSToolsScreen() {
    val resolver = remember { DNSResolver() }
    val scope = rememberCoroutineScope()

    var domain by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<DNSResult?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("DNS Information", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(14.dp))

        OutlinedTextField(
            value = domain,
            onValueChange = { domain = it },
            label = { Text("Domain (e.g. example.com)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                scope.launch {
                    isLoading = true
                    result = resolver.lookup(domain.trim())
                    isLoading = false
                }
            },
            enabled = !isLoading && domain.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isLoading) "Looking up..." else "Lookup")
        }

        result?.let { r ->
            Spacer(Modifier.height(16.dp))
            TerminalPanel(modifier = Modifier.weight(1f)) {
                if (r.error != null) {
                    TerminalLine("Error: ${r.error}")
                } else {
                    TerminalLine("Query: ${r.query}", color = AccentCyan)
                    TerminalLine("")
                    TerminalLine("A records:")
                    if (r.aRecords.isEmpty()) TerminalLine("  (none)") else r.aRecords.forEach { TerminalLine("  $it") }
                    TerminalLine("")
                    TerminalLine("AAAA records:")
                    if (r.aaaaRecords.isEmpty()) TerminalLine("  (none)") else r.aaaaRecords.forEach { TerminalLine("  $it") }
                    TerminalLine("")
                    TerminalLine("Reverse DNS: ${r.reverseDns ?: "(none)"}")
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "MX / NS / TXT records require adding the dnsjava library " +
                    "(see DNSResolver.kt for details) - not bundled by default.",
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}
