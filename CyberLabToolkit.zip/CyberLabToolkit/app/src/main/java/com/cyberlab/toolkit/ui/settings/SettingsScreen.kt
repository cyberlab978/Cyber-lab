package com.cyberlab.toolkit.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text(
            "CyberLab Toolkit stores all scan data locally on your device. " +
                "No account, no cloud sync, no analytics.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun AboutScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("About & Ethical Use", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text(
            "CyberLab Toolkit is built for cybersecurity students and ethical " +
                "hackers to learn networking and security concepts hands-on.",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Only use the scanning features on devices, networks, and domains " +
                "you own or have explicit written authorization to test. " +
                "Unauthorized scanning or access attempts may be illegal under " +
                "computer misuse laws in your country. This app does not include " +
                "and will never include credential theft, malware, exploit " +
                "automation, or any unauthorized-access functionality.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
