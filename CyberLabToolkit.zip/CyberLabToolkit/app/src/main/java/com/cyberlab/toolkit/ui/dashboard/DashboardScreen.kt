package com.cyberlab.toolkit.ui.dashboard

import android.content.Context
import android.net.wifi.WifiManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cyberlab.toolkit.core.networkscanner.NetworkScanner
import com.cyberlab.toolkit.ui.theme.AccentCyan

data class DashboardAction(val label: String, val icon: ImageVector, val route: String)

private val quickActions = listOf(
    DashboardAction("Network Scan", Icons.Filled.Devices, "network_scanner"),
    DashboardAction("Port Scan", Icons.Filled.SettingsEthernet, "port_scanner"),
    DashboardAction("Header Check", Icons.Filled.Shield, "header_checker"),
    DashboardAction("DNS Tools", Icons.Filled.Dns, "dns_tools"),
    DashboardAction("Password Check", Icons.Filled.Password, "password_analyzer"),
    DashboardAction("History", Icons.Filled.History, "history")
)

@Composable
fun DashboardScreen(onNavigate: (String) -> Unit) {
    val context = LocalContext.current
    val scanner = remember { NetworkScanner() }
    val localIp = remember { scanner.getLocalIpAddress() ?: "Unavailable" }
    val wifiInfo = remember { getWifiSummary(context) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("CyberLab Toolkit", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Authorized network & device security testing",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )

        Spacer(Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Network Info", style = MaterialTheme.typography.titleMedium, color = AccentCyan)
                Spacer(Modifier.height(8.dp))
                InfoRow("Device IP", localIp)
                InfoRow("Wi-Fi SSID", wifiInfo.ssid)
                InfoRow("Gateway", wifiInfo.gateway)
                InfoRow("DNS", wifiInfo.dns)
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("Quick Actions", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(quickActions) { action ->
                ElevatedCard(
                    onClick = { onNavigate(action.route) },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(14.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(action.icon, contentDescription = null, tint = AccentCyan)
                        Spacer(Modifier.height(8.dp))
                        Text(action.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }
}

private data class WifiSummary(val ssid: String, val gateway: String, val dns: String)

private fun getWifiSummary(context: Context): WifiSummary {
    return try {
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wifiManager.connectionInfo
        val dhcp = wifiManager.dhcpInfo
        val ssid = info?.ssid?.trim('"') ?: "Unavailable"
        val gateway = dhcp?.gateway?.let { intToIp(it) } ?: "Unavailable"
        val dns = dhcp?.dns1?.let { intToIp(it) } ?: "Unavailable"
        WifiSummary(ssid, gateway, dns)
    } catch (e: Exception) {
        WifiSummary("Unavailable", "Unavailable", "Unavailable")
    }
}

private fun intToIp(addr: Int): String =
    "${addr and 0xFF}.${(addr shr 8) and 0xFF}.${(addr shr 16) and 0xFF}.${(addr shr 24) and 0xFF}"
