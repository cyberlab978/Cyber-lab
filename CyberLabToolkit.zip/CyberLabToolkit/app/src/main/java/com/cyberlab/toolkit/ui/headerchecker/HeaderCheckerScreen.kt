package com.cyberlab.toolkit.ui.headerchecker

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cyberlab.toolkit.core.headeranalyzer.HeaderAnalyzer
import com.cyberlab.toolkit.core.headeranalyzer.HeaderScanResult
import com.cyberlab.toolkit.ui.components.AuthorizationNotice
import com.cyberlab.toolkit.ui.theme.AccentGreen
import com.cyberlab.toolkit.ui.theme.AccentRed
import kotlinx.coroutines.launch

@Composable
fun HeaderCheckerScreen() {
    val analyzer = remember { HeaderAnalyzer() }
    val scope = rememberCoroutineScope()

    var url by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<HeaderScanResult?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Security Header Checker", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        AuthorizationNotice()
        Spacer(Modifier.height(14.dp))

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Authorized URL (e.g. example.com)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                scope.launch {
                    isLoading = true
                    result = analyzer.analyze(url.trim())
                    isLoading = false
                }
            },
            enabled = !isLoading && url.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isLoading) "Checking..." else "Check Headers")
        }

        if (isLoading) {
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        result?.let { r ->
            Spacer(Modifier.height(16.dp))
            if (r.error != null) {
                Text("Error: ${r.error}", color = AccentRed)
            } else {
                Text("Security Score: ${r.score}/100", style = MaterialTheme.typography.titleMedium)
                Text("HTTP Status: ${r.statusCode}", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(10.dp))
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(r.checks) { check ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(10.dp)) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(check.headerName, style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        if (check.present) "PRESENT" else "MISSING",
                                        color = if (check.present) AccentGreen else AccentRed,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(check.explanation, style = MaterialTheme.typography.bodySmall)
                                check.value?.let {
                                    Spacer(Modifier.height(2.dp))
                                    Text("Value: $it", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
