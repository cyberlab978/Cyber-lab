package com.cyberlab.toolkit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.cyberlab.toolkit.ui.dashboard.DashboardScreen
import com.cyberlab.toolkit.ui.dnstools.DNSToolsScreen
import com.cyberlab.toolkit.ui.headerchecker.HeaderCheckerScreen
import com.cyberlab.toolkit.ui.history.HistoryScreen
import com.cyberlab.toolkit.ui.networkscanner.NetworkScannerScreen
import com.cyberlab.toolkit.ui.passwordanalyzer.PasswordAnalyzerScreen
import com.cyberlab.toolkit.ui.portscanner.PortScannerScreen
import com.cyberlab.toolkit.ui.settings.AboutScreen
import com.cyberlab.toolkit.ui.settings.SettingsScreen
import com.cyberlab.toolkit.ui.theme.CyberLabToolkitTheme

private data class BottomTab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val bottomTabs = listOf(
    BottomTab("dashboard", "Home", Icons.Filled.Home),
    BottomTab("history", "History", Icons.Filled.History),
    BottomTab("settings", "Settings", Icons.Filled.Settings),
    BottomTab("about", "About", Icons.Filled.Info)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CyberLabToolkitTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    CyberLabApp()
                }
            }
        }
    }
}

@Composable
fun CyberLabApp() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = backStackEntry?.destination
                bottomTabs.forEach { tab ->
                    NavigationBarItem(
                        selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true,
                        onClick = {
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "dashboard",
            modifier = Modifier.padding(padding)
        ) {
            composable("dashboard") { DashboardScreen(onNavigate = { navController.navigate(it) }) }
            composable("network_scanner") { NetworkScannerScreen() }
            composable("port_scanner") { PortScannerScreen() }
            composable("header_checker") { HeaderCheckerScreen() }
            composable("dns_tools") { DNSToolsScreen() }
            composable("password_analyzer") { PasswordAnalyzerScreen() }
            composable("history") { HistoryScreen() }
            composable("settings") { SettingsScreen() }
            composable("about") { AboutScreen() }
        }
    }
}
