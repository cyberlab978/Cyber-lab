package com.cyberlab.toolkit.core.passwordanalyzer

import kotlin.math.log2

enum class StrengthLevel { VERY_WEAK, WEAK, FAIR, STRONG, VERY_STRONG }

data class PasswordAnalysis(
    val strength: StrengthLevel,
    val entropyBits: Double,
    val issues: List<String>,
    val suggestions: List<String>
)

private val COMMON_PASSWORDS = setOf(
    "password", "123456", "12345678", "qwerty", "abc123", "letmein",
    "admin", "welcome", "monkey", "iloveyou", "password1", "123456789",
    "football", "dragon", "master", "sunshine"
)

/**
 * Purely local password-strength heuristics. The password text never
 * leaves the device, is never logged, and is never persisted - callers
 * must not store the raw string in scan history or any other file.
 */
class PasswordAnalyzer {

    fun analyze(password: String): PasswordAnalysis {
        val issues = mutableListOf<String>()
        val suggestions = mutableListOf<String>()

        if (password.isEmpty()) {
            return PasswordAnalysis(StrengthLevel.VERY_WEAK, 0.0, listOf("Empty password"), listOf("Enter a password"))
        }

        val lower = password.lowercase()
        val hasLower = password.any { it.isLowerCase() }
        val hasUpper = password.any { it.isUpperCase() }
        val hasDigit = password.any { it.isDigit() }
        val hasSymbol = password.any { !it.isLetterOrDigit() }

        var poolSize = 0
        if (hasLower) poolSize += 26
        if (hasUpper) poolSize += 26
        if (hasDigit) poolSize += 10
        if (hasSymbol) poolSize += 32

        val entropy = if (poolSize > 0) password.length * log2(poolSize.toDouble()) else 0.0

        if (password.length < 8) {
            issues.add("Shorter than 8 characters")
            suggestions.add("Use at least 12 characters")
        }
        if (!hasUpper) { issues.add("No uppercase letters"); suggestions.add("Add uppercase letters") }
        if (!hasLower) { issues.add("No lowercase letters"); suggestions.add("Add lowercase letters") }
        if (!hasDigit) { issues.add("No digits"); suggestions.add("Add digits") }
        if (!hasSymbol) { issues.add("No symbols"); suggestions.add("Add symbols like !@#$%") }

        if (COMMON_PASSWORDS.contains(lower)) {
            issues.add("Matches a commonly-used password")
            suggestions.add("Avoid common words and known leaked passwords")
        }
        if (Regex("(.)\\1{2,}").containsMatchIn(password)) {
            issues.add("Contains repeated character sequences")
        }
        if (isSequential(lower)) {
            issues.add("Contains a sequential pattern (e.g. abc, 123)")
        }

        val strength = when {
            entropy < 28 || COMMON_PASSWORDS.contains(lower) -> StrengthLevel.VERY_WEAK
            entropy < 36 -> StrengthLevel.WEAK
            entropy < 60 -> StrengthLevel.FAIR
            entropy < 80 -> StrengthLevel.STRONG
            else -> StrengthLevel.VERY_STRONG
        }

        if (suggestions.isEmpty() && strength != StrengthLevel.VERY_STRONG) {
            suggestions.add("Consider a longer passphrase for extra margin")
        }

        return PasswordAnalysis(strength, entropy, issues, suggestions)
    }

    private fun isSequential(s: String): Boolean {
        val sequences = listOf("abcdefghijklmnopqrstuvwxyz", "0123456789", "qwertyuiop")
        for (seq in sequences) {
            for (i in 0..seq.length - 3) {
                val chunk = seq.substring(i, i + 3)
                if (s.contains(chunk)) return true
            }
        }
        return false
    }
}
