# CyberLab Toolkit

An Android app for cybersecurity students and ethical hackers to learn and
practice network/security testing concepts against **their own devices,
local networks, CTF/lab environments, and systems they are explicitly
authorized to test.**

This project intentionally contains **no** credential theft, phishing,
malware, keylogging, persistence, stealth/evasion, DDoS, exploit
automation, or unauthorized-access functionality. Every active scan
(network sweep, port scan, header check) requires the user to type in a
target and, for port scanning, confirm an authorization dialog first.

## 1. Project structure

```
CyberLabToolkit/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/cyberlab/toolkit/
│       │   ├── MainActivity.kt              # Nav host + bottom nav
│       │   ├── core/                        # Pure logic, no UI deps
│       │   │   ├── networkscanner/NetworkScanner.kt
│       │   │   ├── portscanner/PortScanner.kt
│       │   │   ├── dnsresolver/DNSResolver.kt
│       │   │   ├── headeranalyzer/HeaderAnalyzer.kt
│       │   │   ├── passwordanalyzer/PasswordAnalyzer.kt
│       │   │   └── storage/ScanHistoryStore.kt
│       │   └── ui/                          # Jetpack Compose screens
│       │       ├── dashboard/DashboardScreen.kt
│       │       ├── networkscanner/NetworkScannerScreen.kt
│       │       ├── portscanner/PortScannerScreen.kt
│       │       ├── headerchecker/HeaderCheckerScreen.kt
│       │       ├── dnstools/DNSToolsScreen.kt
│       │       ├── passwordanalyzer/PasswordAnalyzerScreen.kt
│       │       ├── history/HistoryScreen.kt
│       │       ├── settings/SettingsScreen.kt (Settings + About)
│       │       ├── components/ (AuthorizationNotice, TerminalPanel)
│       │       └── theme/Theme.kt
│       └── res/
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## 2. Module explanations

- **NetworkScanner** — finds the device's own IP/subnet, then sweeps the
  /24 range with `InetAddress.isReachable()` concurrently via coroutines.
  Best-effort MAC lookup from `/proc/net/arp` (may be empty on newer
  Android versions — that's expected, not a bug).
- **PortScanner** — plain TCP `connect()` attempts against a
  user-supplied, user-confirmed host. Classifies OPEN / CLOSED / FILTERED
  by connection result and timeout. No banner grabbing, no payloads.
- **DNSResolver** — A/AAAA + reverse DNS via `InetAddress`. MX/NS/TXT
  need an external DNS library (see note below); left as an extension
  point rather than silently bundled.
- **HeaderAnalyzer** — issues a single GET to a user-supplied URL and
  reports which of 6 common security headers (HSTS, CSP, X-Content-Type-
  Options, X-Frame-Options, Referrer-Policy, Permissions-Policy) are
  present, with a 0–100 score and plain-English explanations.
- **PasswordAnalyzer** — 100% local entropy/pattern heuristics. The
  password string is never logged, stored, or included in exported scan
  history — only metadata (score, timestamp) should ever be persisted if
  you wire history logging into this screen.
- **ScanHistoryStore** — simple JSON file in app-private storage
  (`filesDir`). Stores only target/type/summary/timestamp — never raw
  scan payloads or credentials. Supports search, delete, clear, and
  TXT/CSV export strings (wire export to `Intent.ACTION_SEND` or
  `MediaStore` to let the user save/share the file).

## 3. Adding MX/NS/TXT DNS record support

Android's built-in resolver only exposes A/AAAA. To add the other record
types, include `dnsjava` in `app/build.gradle.kts`:

```kotlin
implementation("dnsjava:dnsjava:3.6.1")
```

then extend `DNSResolver.kt` using `org.xbill.DNS.Lookup` with
`Type.MX`, `Type.NS`, `Type.TXT`. This was left out of the default
dependency set so adding raw DNS query capability is a deliberate choice
by whoever builds the project.

## 4. Build instructions

1. Install **Android Studio** (Koala/2024.1 or newer) with the Android
   SDK 34 platform installed.
2. Open this folder (`CyberLabToolkit/`) as a project in Android Studio
   — it will generate the Gradle wrapper jar automatically on first
   sync. (If you're building purely from the command line, run
   `gradle wrapper` once inside this folder to generate
   `gradlew` / `gradlew.bat` and the wrapper jar, since binary jar files
   aren't included in this delivery.)
3. Let Gradle sync and download dependencies.
4. Run `./gradlew assembleDebug` from a terminal, **or** click **Run ▶**
   in Android Studio with a device/emulator selected.

## 5. Generating a debug APK

```bash
./gradlew assembleDebug
```

The APK will be output to:

```
app/build/outputs/apk/debug/app-debug.apk
```

Install it on a connected device/emulator with:

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

## 6. Testing instructions (safe, authorized targets only)

- **Network Scanner**: run on your home/lab Wi-Fi to discover your own
  router, laptop, phone, IoT devices, etc.
- **Port Scanner**: point it at `127.0.0.1` (localhost) or a VM/container
  you control (e.g. a local `docker run -p 8080:80 nginx`), or a
  deliberately-vulnerable lab target such as OWASP Juice Shop / Metasploitable
  running in your **own** isolated lab network.
- **Header Checker**: test against your own website/staging environment,
  or public "check my headers" test targets that explicitly allow
  automated requests (check their terms first).
- **DNS Tools**: safe against any public domain — DNS lookups are
  passive/read-only by nature.
- **Password Analyzer**: fully offline, test with any sample strings.

## 7. Permissions

Only three are requested, all standard and non-dangerous (no runtime
prompt needed on modern Android):

- `INTERNET` — required for all TCP/HTTP/DNS operations
- `ACCESS_NETWORK_STATE` — for connectivity checks
- `ACCESS_WIFI_STATE` — to read SSID/gateway/DNS info for the dashboard

## 8. Ethical use

See the in-app **About** tab and the `AuthorizationNotice` banner shown
before every active scan. This project is for learning; do not point any
scanning feature at systems you don't own or have written permission to
test.
